package emu.web.com.github.xpenatan.jParser.loader;

import com.github.xpenatan.jmultiplatform.core.JMultiplatform;
import com.github.xpenatan.jParser.loader.JParserLibraryLoaderListener;
import com.github.xpenatan.jParser.loader.JParserLibraryLoaderOptions;
import com.github.xpenatan.jParser.loader.JParserLibraryLoaderPlatform;
import java.util.HashSet;
import org.teavm.jso.JSBody;
import org.teavm.jso.JSFunctor;
import org.teavm.jso.browser.Window;
import org.teavm.jso.dom.html.HTMLDocument;
import org.teavm.jso.dom.html.HTMLScriptElement;

public class JParserLibraryLoader {

    private static final String DEFAULT_SCRIPT_PATH = "scripts/";

    private static HashSet<String> loadedLibraries = new HashSet<>();

    private JParserLibraryLoader() {}

    public static void load(String libraryName, JParserLibraryLoaderListener listener) {
        loadInternal(libraryName, null, listener);
    }

    public static void load(String libraryName, JParserLibraryLoaderOptions options, JParserLibraryLoaderListener listener) {
        loadInternal(libraryName, options, listener);
    }

    private static void loadInternal(String libraryName, JParserLibraryLoaderOptions options, JParserLibraryLoaderListener listener) {
        if(listener == null) {
            throw new RuntimeException("Should implement listener");
        }

        String path = null;
        if(options != null) {
            path = options.path;
        }
        if(path == null) {
            path = "";
        }
        else {
            path += "/";
            path = path.replace("//", "/");
        }

        final String fullLibraryName = path + libraryName;

        if(loadedLibraries.contains(fullLibraryName)) {
            listener.onLoad(true, null);
            return;
        }

        JParserLibraryLoaderListener lis = new JParserLibraryLoaderListener() {
            @Override
            public void onLoad(boolean isSuccess, Throwable t) {
                listener.onLoad(isSuccess, t);
            }
        };

        String scriptPath = getScriptPath();
        if(fullLibraryName.endsWith(".js")) {
            loadJS(lis, fullLibraryName, scriptPath);
        }
        else {
            loadWasm(lis, fullLibraryName, scriptPath, ".js",true);
        }
    }

    private static String getScriptPath() {
        String scriptPath = JMultiplatform.getInstance().getMap().getObject(JParserLibraryLoaderPlatform.PLATFORM_WEB_SCRIPT_PATH, String.class);
        if(scriptPath == null) {
            return DEFAULT_SCRIPT_PATH;
        }
        if(scriptPath.length() > 0 && !scriptPath.endsWith("/")) {
            return scriptPath + "/";
        }
        return scriptPath;
    }

    private static void loadWasm(JParserLibraryLoaderListener listener, String libraryName, String prefix, String postfix, boolean autoLoadWasm) {
        if(autoLoadWasm) {
            String fullLibName = libraryName + "OnInit";
            setOnLoadInit(fullLibName, () -> {
                loadedLibraries.add(libraryName);
                listener.onLoad(true, null);
            });
        }
        loadScript(libraryName, (isSuccess, e) -> {
            if(isSuccess) {
                initializeModule(libraryName);
                // Wasm requires to setup wasm first
                if(!autoLoadWasm) {
                    listener.onLoad(true, null);
                }
            }
            else {
                listener.onLoad(false, e);
            }
        }, prefix, postfix);
    }

    private static void loadJS(JParserLibraryLoaderListener listener, String libraryName, String prefix) {
        loadScript(libraryName, (isSuccess, e) -> {
            if(isSuccess) {
                listener.onLoad(true, null);
            }
            else {
                listener.onLoad(false, e);
            }
        }, prefix, "");
    }

    private static void loadScript(String libraryName, JParserLibraryLoaderListener listener, String prefix, String postfix) {
        String url = prefix + libraryName + postfix;
        Window current = Window.current();
        HTMLDocument document = current.getDocument();
        HTMLScriptElement scriptElement = (HTMLScriptElement)document.createElement("script");
        scriptElement.addEventListener("load", event -> {
            listener.onLoad(true, null);
        });
        scriptElement.addEventListener("error", (error) -> {
            listener.onLoad(false, new IllegalStateException("Failed to load javascript: " + url));
        });
        scriptElement.setSrc(url);
        document.getBody().appendChild(scriptElement);
    }

    @JSFunctor
    public interface OnInitFunction extends org.teavm.jso.JSObject {
        void onInit();
    }

    @JSBody(params = { "libraryName", "onInitFunction" }, script = "" +
            "window[libraryName] = onInitFunction;"
    )
    private static native void setOnLoadInit(String libraryName, OnInitFunction onInitFunction);

    @JSBody(params = { "libraryName" }, script = "" +
            "window[libraryName]().then(function(r) {" +
            "    window[libraryName] = r;" +
            "    window[libraryName + 'OnInit']();" +
            "});"
    )
    private static native void initializeModule(String libraryName);
}
