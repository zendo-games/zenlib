package gen.web.com.github.xpenatan.jParser.api;

/**
 * @author xpenatan
 */
public class NativeObject {

    public final static NativeObject NULL;

    static {
        NULL = native_new();
    }

    public static NativeObject native_new() {
        return new NativeObject((byte)0, (char)0);
    }

    public static boolean ENABLE_LOGGING = true;

    /**
     * Native address. Used internally. Don't change.
     */

    public int native_address;
    public int native_void_address;

    private boolean native_cMemOwn;
    private boolean native_disposed;

    public org.teavm.jso.JSObject native_object;

    public NativeObject() {
    }

    @Deprecated()
    public NativeObject(byte b, char c) {
    }

    @Deprecated
    public final void internal_reset(int address, boolean cMemoryOwn) {
        native_cMemOwn = cMemoryOwn;
        native_address = address;
        native_void_address = address;
        native_disposed = false;
        native_object = null;
        if(address != 0) {
            onNativeAddressChanged();
        }
    }

    public final NativeObject native_setAddress(long voidValue) {
        native_address = (int)voidValue;
        native_void_address = (int)voidValue;
        if(voidValue != 0) {
            onNativeAddressChanged();
        }
        return this;
    }

    public final NativeObject native_setAddress(int voidValue) {
        native_address = voidValue;
        native_void_address = voidValue;
        if(voidValue != 0) {
            onNativeAddressChanged();
        }
        return this;
    }

    public final long native_getAddressLong() {
        return native_address;
    }

    public final int native_getAddressInt() {
        return (int)native_address;
    }

    public final boolean native_isNULL() {
        return native_address == 0;
    }

    /**
     * Reset this instance to default state. Use only in instance created by you.
     * Caution: Resetting an owned native instance will cause a memory leak if not disposed.
     */
    public final NativeObject native_reset() {
        native_cMemOwn = false;
        native_disposed = false;
        native_object = null;
        native_address = 0;
        native_void_address = 0;
        return this;
    }

    /**
     * Take ownership of the native instance, causing the native object to be warned when this object gets out of scope without disposing.
     */
    public final void native_takeOwnership() {
        native_cMemOwn = true;
    }

    /**
     * Release ownership of the native instance, causing the native object NOT to be warned when this object gets out of scope.
     */
    public final void native_releaseOwnership() {
        native_cMemOwn = false;
    }

    public boolean native_hasOwnership() {
        return native_cMemOwn;
    }

    /**
     * Copy the address data and set ownership/disposed to false
     */
    public final void native_copy(NativeObject other) {
        this.native_address = other.native_address;
        this.native_object = other.native_object;
        this.native_void_address = other.native_void_address;
        this.native_disposed = false;
        this.native_cMemOwn = false;
        if(native_address != 0) {
            onNativeAddressChanged();
        }
    }

    public final boolean isDisposed() {
        return native_disposed;
    }

    public final void dispose() {
        if(native_cMemOwn) {
            if(!native_disposed) {
                if(native_address != 0) {
                    native_disposed = true;
                    deleteNative();
                    native_address = 0;
                    native_void_address = 0;
                    native_object = null;
                    onNativeDispose();
                }
                else {
                    if(NativeObject.ENABLE_LOGGING) {
                        error("Native", "Disposing error - " + this + " native_address is 0");
                    }
                }
            }
            else {
                if(NativeObject.ENABLE_LOGGING) {
                    error("Native", "Disposing warning - " + this + " is already disposed");
                }
            }
        }
        else {
            if(NativeObject.ENABLE_LOGGING) {
                error("Native", "Disposing warning - " + this + " is not memory owned");
            }
        }
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" + native_address + "," + native_cMemOwn + ")";
    }

    /**
     * Deletes the Native object this class encapsulates. Do not call directly, instead use the {@link #dispose()} method.
     */
    protected void deleteNative() {
    }

    protected void onNativeAddressChanged() {
    }

    protected void onNativeDispose() {
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof NativeObject) {
            NativeObject nativeObj = (NativeObject)obj;
            return nativeObj.native_address == this.native_address;
        }
        return false;
    }

    /**
     * Logs an error message to the console or logcat
     */
    public static void error(String tag, String message) {
        System.err.println(tag + ": " + message);
    }
}
